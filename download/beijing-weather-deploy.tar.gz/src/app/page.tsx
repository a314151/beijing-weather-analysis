'use client'

import { useState, useEffect, useCallback } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts'

// 数据类型定义
interface Summary {
  total_days: number
  date_range: { start: string; end: string }
  years: number
  model_metrics: {
    rmse_max: number
    rmse_min: number
    mae_max: number
    mae_min: number
  }
  data_sources: Array<{
    name: string
    url: string
    description: string
  }>
}

interface MonthlyData {
  [key: string]: {
    avg_max: number
    avg_min: number
    std_max: number
    std_min: number
  }
}

interface YearlyData {
  [key: string]: {
    avg_max: number
    avg_min: number
  }
}

interface Prediction {
  date: string
  day_of_year: number
  predicted_max_temp: number
  predicted_min_temp: number
  model_metrics: {
    rmse_max: number
    rmse_min: number
    mae_max: number
    mae_min: number
  }
}

interface HistoryItem {
  date: string
  max_temp: number
  min_temp: number
}

export default function Home() {
  const [summary, setSummary] = useState<Summary | null>(null)
  const [monthlyData, setMonthlyData] = useState<MonthlyData | null>(null)
  const [yearlyData, setYearlyData] = useState<YearlyData | null>(null)
  const [prediction, setPrediction] = useState<Prediction | null>(null)
  const [historyData, setHistoryData] = useState<HistoryItem[]>([])
  const [selectedDate, setSelectedDate] = useState<string>('')
  const [selectedYear, setSelectedYear] = useState<string>('2024')
  const [activeTab, setActiveTab] = useState<'overview' | 'charts' | 'predict' | 'history'>('overview')
  const [loading, setLoading] = useState(true)

  // 获取数据概览
  const fetchSummary = useCallback(async () => {
    try {
      const res = await fetch('/api/weather?action=summary')
      const data = await res.json()
      setSummary(data)
    } catch (error) {
      console.error('Failed to fetch summary:', error)
    }
  }, [])

  // 获取月度数据
  const fetchMonthlyData = useCallback(async () => {
    try {
      const res = await fetch('/api/weather?action=monthly')
      const data = await res.json()
      setMonthlyData(data)
    } catch (error) {
      console.error('Failed to fetch monthly data:', error)
    }
  }, [])

  // 获取年度数据
  const fetchYearlyData = useCallback(async () => {
    try {
      const res = await fetch('/api/weather?action=yearly')
      const data = await res.json()
      setYearlyData(data)
    } catch (error) {
      console.error('Failed to fetch yearly data:', error)
    }
  }, [])

  // 获取历史数据
  const fetchHistoryData = useCallback(async (year: string) => {
    try {
      const res = await fetch(`/api/weather?action=history&year=${year}&limit=400`)
      const data = await res.json()
      setHistoryData(data.data || [])
    } catch (error) {
      console.error('Failed to fetch history data:', error)
    }
  }, [])

  // 预测温度
  const predictTemperature = async () => {
    if (!selectedDate) return
    try {
      const res = await fetch(`/api/weather?action=predict&date=${selectedDate}`)
      const data = await res.json()
      setPrediction(data)
    } catch (error) {
      console.error('Failed to predict:', error)
    }
  }

  // 初始化数据
  useEffect(() => {
    const init = async () => {
      setLoading(true)
      await Promise.all([fetchSummary(), fetchMonthlyData(), fetchYearlyData()])
      setLoading(false)
    }
    init()
  }, [fetchSummary, fetchMonthlyData, fetchYearlyData])

  // 加载历史数据
  useEffect(() => {
    if (activeTab === 'history') {
      const loadHistory = async () => {
        try {
          const res = await fetch(`/api/weather?action=history&year=${selectedYear}&limit=400`)
          const data = await res.json()
          setHistoryData(data.data || [])
        } catch (error) {
          console.error('Failed to fetch history data:', error)
        }
      }
      loadHistory()
    }
  }, [activeTab, selectedYear])

  // 准备月度图表数据
  const monthlyChartData = monthlyData ? Object.entries(monthlyData).map(([month, data]) => ({
    month: `${month}月`,
    avg_max: Math.round(data.avg_max * 10) / 10,
    avg_min: Math.round(data.avg_min * 10) / 10,
    max_upper: Math.round((data.avg_max + data.std_max) * 10) / 10,
    max_lower: Math.round((data.avg_max - data.std_max) * 10) / 10,
    min_upper: Math.round((data.avg_min + data.std_min) * 10) / 10,
    min_lower: Math.round((data.avg_min - data.std_min) * 10) / 10,
  })) : []

  // 准备年度图表数据
  const yearlyChartData = yearlyData ? Object.entries(yearlyData)
    .filter(([year]) => parseInt(year) >= 1950)
    .map(([year, data]) => ({
      year,
      avg_max: Math.round(data.avg_max * 10) / 10,
      avg_min: Math.round(data.avg_min * 10) / 10,
    })) : []

  // 准备历史数据图表
  const historyChartData = historyData.map(item => ({
    date: item.date.slice(5), // 只显示月-日
    fullDate: item.date,
    max_temp: item.max_temp,
    min_temp: item.min_temp,
  }))

  // 获取年份列表
  const years = []
  for (let y = 2024; y >= 1940; y--) {
    years.push(y.toString())
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">加载中...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* 头部 */}
      <header className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-gray-800">
            🌤️ 北京历史温度数据分析与预测系统
          </h1>
          <p className="text-gray-600 mt-2">
            基于1940-2026年共{summary?.total_days?.toLocaleString()}天的历史天气数据
          </p>
        </div>
      </header>

      {/* 导航标签 */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8">
            {[
              { key: 'overview', label: '📊 数据概览' },
              { key: 'charts', label: '📈 温度图表' },
              { key: 'predict', label: '🔮 温度预测' },
              { key: 'history', label: '📋 历史数据' },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as typeof activeTab)}
                className={`py-4 px-2 border-b-2 font-medium transition-colors ${
                  activeTab === tab.key
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* 数据概览 */}
        {activeTab === 'overview' && summary && (
          <div className="space-y-6">
            {/* 统计卡片 */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="text-4xl mb-2">📅</div>
                <div className="text-3xl font-bold text-blue-600">{summary.total_days.toLocaleString()}</div>
                <div className="text-gray-500">总数据天数</div>
              </div>
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="text-4xl mb-2">📆</div>
                <div className="text-3xl font-bold text-green-600">{summary.years}</div>
                <div className="text-gray-500">数据年份</div>
              </div>
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="text-4xl mb-2">🌡️</div>
                <div className="text-3xl font-bold text-red-600">{summary.model_metrics.rmse_max.toFixed(2)}°C</div>
                <div className="text-gray-500">最高温预测误差(RMSE)</div>
              </div>
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="text-4xl mb-2">❄️</div>
                <div className="text-3xl font-bold text-indigo-600">{summary.model_metrics.rmse_min.toFixed(2)}°C</div>
                <div className="text-gray-500">最低温预测误差(RMSE)</div>
              </div>
            </div>

            {/* 数据来源 */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">📡 数据来源</h2>
              <div className="space-y-4">
                {summary.data_sources.map((source, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4">
                    <h3 className="font-semibold text-gray-800">{source.name}</h3>
                    <p className="text-gray-600">{source.description}</p>
                    <a href={source.url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                      {source.url}
                    </a>
                  </div>
                ))}
              </div>
            </div>

            {/* 日期范围 */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">📅 数据日期范围</h2>
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{summary.date_range.start}</div>
                  <div className="text-gray-500">开始日期</div>
                </div>
                <div className="flex-1 h-2 bg-gradient-to-r from-blue-200 to-blue-600 rounded-full"></div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{summary.date_range.end}</div>
                  <div className="text-gray-500">结束日期</div>
                </div>
              </div>
            </div>

            {/* 模型说明 */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">🤖 预测模型说明</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">模型类型</h3>
                  <p className="text-gray-600">傅里叶级数拟合模型（4阶谐波）</p>
                  <p className="text-gray-500 text-sm mt-2">
                    该模型利用傅里叶级数的周期性特性，能够很好地捕捉温度随季节变化的规律。
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">模型精度</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">最高温度 MAE:</span>
                      <span className="font-semibold">{summary.model_metrics.mae_max.toFixed(2)}°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">最低温度 MAE:</span>
                      <span className="font-semibold">{summary.model_metrics.mae_min.toFixed(2)}°C</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 温度图表 */}
        {activeTab === 'charts' && (
          <div className="space-y-8">
            {/* 月度温度图表 */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">📊 月度平均温度变化</h2>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlyChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[-15, 40]} />
                    <Tooltip />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="avg_max"
                      stroke="#ef4444"
                      fill="#fecaca"
                      name="平均最高温 (°C)"
                    />
                    <Area
                      type="monotone"
                      dataKey="avg_min"
                      stroke="#3b82f6"
                      fill="#bfdbfe"
                      name="平均最低温 (°C)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* 年度温度图表 */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">📈 年度平均温度变化趋势</h2>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={yearlyChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" interval={4} />
                    <YAxis domain={[5, 20]} />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="avg_max"
                      stroke="#ef4444"
                      strokeWidth={2}
                      dot={false}
                      name="年平均最高温 (°C)"
                    />
                    <Line
                      type="monotone"
                      dataKey="avg_min"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      dot={false}
                      name="年平均最低温 (°C)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* 静态图表 */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">🖼️ 详细温度分析图</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">每日温度曲线</h3>
                  <img src="/download/daily_temperature.png" alt="每日温度曲线" className="w-full rounded-lg shadow" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">近年温度对比</h3>
                  <img src="/download/recent_years_temperature.png" alt="近年温度对比" className="w-full rounded-lg shadow" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 温度预测 */}
        {activeTab === 'predict' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">🔮 温度预测</h2>
              <div className="flex flex-col md:flex-row gap-4 items-end">
                <div className="flex-1">
                  <label className="block text-gray-700 font-medium mb-2">选择日期</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <button
                  onClick={predictTemperature}
                  disabled={!selectedDate}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  预测温度
                </button>
              </div>
            </div>

            {prediction && (
              <div className="bg-white rounded-xl shadow-md p-6">
                <h2 className="text-xl font-bold text-gray-800 mb-4">📍 预测结果</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-red-50 rounded-xl">
                    <div className="text-5xl mb-2">🌡️</div>
                    <div className="text-4xl font-bold text-red-600">{prediction.predicted_max_temp}°C</div>
                    <div className="text-gray-600">预测最高温度</div>
                  </div>
                  <div className="text-center p-6 bg-blue-50 rounded-xl">
                    <div className="text-5xl mb-2">❄️</div>
                    <div className="text-4xl font-bold text-blue-600">{prediction.predicted_min_temp}°C</div>
                    <div className="text-gray-600">预测最低温度</div>
                  </div>
                  <div className="text-center p-6 bg-gray-50 rounded-xl">
                    <div className="text-5xl mb-2">📅</div>
                    <div className="text-2xl font-bold text-gray-800">{prediction.date}</div>
                    <div className="text-gray-600">一年中第 {prediction.day_of_year} 天</div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-yellow-50 rounded-lg">
                  <p className="text-yellow-800">
                    ⚠️ 预测误差范围：最高温 ±{prediction.model_metrics.rmse_max.toFixed(1)}°C，最低温 ±{prediction.model_metrics.rmse_min.toFixed(1)}°C
                  </p>
                </div>
              </div>
            )}

            {/* 快速预测 */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">⚡ 快速预测 - 今日温度</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {['春分', '夏至', '秋分', '冬至'].map((season, index) => {
                  const dates = ['03-20', '06-21', '09-23', '12-22']
                  const year = new Date().getFullYear()
                  return (
                    <button
                      key={season}
                      onClick={() => {
                        setSelectedDate(`${year}-${dates[index]}`)
                        setTimeout(predictTemperature, 100)
                      }}
                      className="p-4 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-xl hover:from-blue-200 hover:to-indigo-200 transition-colors"
                    >
                      <div className="text-2xl mb-1">{['🌸', '☀️', '🍂', '❄️'][index]}</div>
                      <div className="font-semibold">{season}</div>
                      <div className="text-sm text-gray-500">{dates[index]}</div>
                    </button>
                  )
                })}
              </div>
            </div>
          </div>
        )}

        {/* 历史数据 */}
        {activeTab === 'history' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <h2 className="text-xl font-bold text-gray-800">📋 历史数据查询</h2>
                <div className="flex items-center gap-4">
                  <label className="text-gray-700">选择年份:</label>
                  <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    {years.map(year => (
                      <option key={year} value={year}>{year}年</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* 历史数据图表 */}
              <div className="h-80 mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={historyChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" interval={30} />
                    <YAxis domain={[-20, 45]} />
                    <Tooltip 
                      formatter={(value: number, name: string) => [`${value}°C`, name === 'max_temp' ? '最高温' : '最低温']}
                      labelFormatter={(label) => `日期: ${label}`}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="max_temp"
                      stroke="#ef4444"
                      strokeWidth={1.5}
                      dot={false}
                      name="最高温度"
                    />
                    <Line
                      type="monotone"
                      dataKey="min_temp"
                      stroke="#3b82f6"
                      strokeWidth={1.5}
                      dot={false}
                      name="最低温度"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* 数据表格 */}
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">日期</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">最高温度</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">最低温度</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">温差</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {historyData.slice(0, 30).map((item, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.date}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">{item.max_temp}°C</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-600 font-medium">{item.min_temp}°C</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{(item.max_temp - item.min_temp).toFixed(1)}°C</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {historyData.length > 30 && (
                <div className="mt-4 text-center text-gray-500">
                  显示前30条数据，共{historyData.length}条
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* 页脚 */}
      <footer className="bg-white border-t mt-8">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center text-gray-500">
          <p>数据来源: Open-Meteo Historical Weather API | 预测模型: 傅里叶级数拟合</p>
          <p className="mt-2">© 2024 北京历史温度数据分析与预测系统</p>
        </div>
      </footer>
    </div>
  )
}
