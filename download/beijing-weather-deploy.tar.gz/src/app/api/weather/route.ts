import { NextRequest, NextResponse } from "next/server";

// 傅里叶级数函数
function fourierSeries(x: number, params: number[]): number {
  const n = Math.floor((params.length - 1) / 2);
  const a0 = params[0] || 0;
  let result = a0;

  for (let i = 0; i < n; i++) {
    if (2 * i + 2 < params.length) {
      const a = params[2 * i + 1];
      const b = params[2 * i + 2];
      result += a * Math.cos((2 * Math.PI * (i + 1) * x) / 365.25) +
                b * Math.sin((2 * Math.PI * (i + 1) * x) / 365.25);
    }
  }

  return result;
}

// 获取一年中的第几天
function getDayOfYear(dateStr: string): number {
  const date = new Date(dateStr);
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  return Math.floor(diff / oneDay);
}

// 缓存数据
let cachedData: {
  training: unknown[] | null;
  statistics: Record<string, unknown> | null;
  model: Record<string, unknown> | null;
} = {
  training: null,
  statistics: null,
  model: null
};

// 获取基础URL
function getBaseUrl(request: NextRequest): string {
  const host = request.headers.get('host') || 'localhost:3000';
  const protocol = request.headers.get('x-forwarded-proto') || 'https';
  return `${protocol}://${host}`;
}

// 异步获取JSON数据
async function fetchJsonData(request: NextRequest, filename: string): Promise<unknown> {
  const baseUrl = getBaseUrl(request);
  const url = `${baseUrl}/data/${filename}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch ${filename}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Error fetching ${filename}:`, error);
    return null;
  }
}

// 获取训练数据
async function getTrainingData(request: NextRequest) {
  if (cachedData.training) return cachedData.training;
  cachedData.training = await fetchJsonData(request, 'beijing_weather_training.json') as unknown[];
  return cachedData.training;
}

// 获取统计数据
async function getStatistics(request: NextRequest) {
  if (cachedData.statistics) return cachedData.statistics;
  cachedData.statistics = await fetchJsonData(request, 'temperature_statistics.json') as Record<string, unknown>;
  return cachedData.statistics;
}

// 获取模型数据
async function getModel(request: NextRequest) {
  if (cachedData.model) return cachedData.model;
  cachedData.model = await fetchJsonData(request, 'temperature_model.json') as Record<string, unknown>;
  return cachedData.model;
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const action = searchParams.get("action");

  try {
    switch (action) {
      case "statistics": {
        const stats = await getStatistics(request);
        if (!stats) {
          return NextResponse.json({ error: "统计数据未找到" }, { status: 404 });
        }
        return NextResponse.json(stats);
      }

      case "model": {
        const model = await getModel(request);
        if (!model) {
          return NextResponse.json({ error: "模型数据未找到" }, { status: 404 });
        }
        return NextResponse.json(model);
      }

      case "predict": {
        const dateStr = searchParams.get("date");
        if (!dateStr) {
          return NextResponse.json({ error: "请提供日期参数" }, { status: 400 });
        }

        const model = await getModel(request) as {
          max_temp_params: number[];
          min_temp_params: number[];
          metrics: { rmse_max: number; rmse_min: number; mae_max: number; mae_min: number };
        } | null;
        
        if (!model) {
          return NextResponse.json({ error: "模型数据未找到" }, { status: 404 });
        }

        const dayOfYear = getDayOfYear(dateStr);
        const maxTemp = fourierSeries(dayOfYear, model.max_temp_params);
        const minTemp = fourierSeries(dayOfYear, model.min_temp_params);

        return NextResponse.json({
          date: dateStr,
          day_of_year: dayOfYear,
          predicted_max_temp: Math.round(maxTemp * 10) / 10,
          predicted_min_temp: Math.round(minTemp * 10) / 10,
          model_metrics: model.metrics,
        });
      }

      case "history": {
        const page = parseInt(searchParams.get("page") || "1");
        const limit = parseInt(searchParams.get("limit") || "365");
        const year = searchParams.get("year");

        const data = await getTrainingData(request) as Array<{ date: string; max_temp: number; min_temp: number }> | null;
        if (!data) {
          return NextResponse.json({ error: "历史数据未找到" }, { status: 404 });
        }

        let filteredData = data;
        if (year) {
          filteredData = data.filter((item) => item.date.startsWith(year));
        }

        const start = (page - 1) * limit;
        const end = start + limit;
        const paginatedData = filteredData.slice(start, end);

        return NextResponse.json({
          total: filteredData.length,
          page,
          limit,
          data: paginatedData,
        });
      }

      case "yearly": {
        const stats = await getStatistics(request) as { yearly?: Record<string, unknown> } | null;
        if (!stats || !stats.yearly) {
          return NextResponse.json({ error: "年度数据未找到" }, { status: 404 });
        }
        return NextResponse.json(stats.yearly);
      }

      case "monthly": {
        const stats = await getStatistics(request) as { monthly?: Record<string, unknown> } | null;
        if (!stats || !stats.monthly) {
          return NextResponse.json({ error: "月度数据未找到" }, { status: 404 });
        }
        return NextResponse.json(stats.monthly);
      }

      case "daily": {
        const stats = await getStatistics(request) as { daily?: Record<string, unknown> } | null;
        if (!stats || !stats.daily) {
          return NextResponse.json({ error: "每日数据未找到" }, { status: 404 });
        }
        return NextResponse.json(stats.daily);
      }

      case "summary": {
        const model = await getModel(request) as {
          metrics: { rmse_max: number; rmse_min: number; mae_max: number; mae_min: number };
        } | null;
        const stats = await getStatistics(request) as {
          yearly?: Record<string, unknown>;
        } | null;
        const rawData = await getTrainingData(request) as Array<{ date: string }> | null;

        if (!model || !stats || !rawData) {
          return NextResponse.json({ error: "数据未找到" }, { status: 404 });
        }

        return NextResponse.json({
          total_days: rawData.length,
          date_range: {
            start: rawData[0]?.date,
            end: rawData[rawData.length - 1]?.date,
          },
          years: Object.keys(stats.yearly || {}).length,
          model_metrics: model.metrics,
          data_sources: [
            {
              name: "Open-Meteo Historical Weather API",
              url: "https://open-meteo.com/en/docs/historical-weather-api",
              description: "提供从1940年至今的历史天气数据",
            },
          ],
        });
      }

      default:
        return NextResponse.json({
          endpoints: [
            { action: "summary", description: "获取数据概览" },
            { action: "statistics", description: "获取温度统计数据" },
            { action: "model", description: "获取模型信息" },
            { action: "predict", params: "date (YYYY-MM-DD)", description: "预测指定日期温度" },
            { action: "history", params: "page, limit, year", description: "获取历史数据" },
            { action: "yearly", description: "获取年度平均数据" },
            { action: "monthly", description: "获取月度平均数据" },
            { action: "daily", description: "获取每日平均数据" },
          ],
        });
    }
  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json(
      { error: "服务器内部错误" },
      { status: 500 }
    );
  }
}
